<?php

namespace Grafikart\UploadBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UploadBundle extends Bundle
{
}
