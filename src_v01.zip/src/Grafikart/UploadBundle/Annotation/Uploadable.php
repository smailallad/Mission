<?php

namespace Grafikart\UploadBundle\Annotation;

use Doctrine\common\Annotaions\Annotation\Target;

/**
* @Annotation
* @Target("CLASS")
*/

class Uploadable {


}
