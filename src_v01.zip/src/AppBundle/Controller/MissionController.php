<?php
namespace AppBundle\Controller;
use AppBundle\Entity\User;
use AppBundle\Entity\Mission;
use Doctrine\ORM\QueryBuilder;
use AppBundle\Form\MissionType;
use AppBundle\Entity\Prestation;
use AppBundle\Entity\Intervention;
use AppBundle\Form\InterventionType;
use AppBundle\Form\MissionFilterType;
use AppBundle\Form\SiteRechercheType;
use AppBundle\Entity\InterventionUser;
use AppBundle\Form\InterventionUserType;
use Symfony\Component\Form\FormInterface;
//use Symfony\Component\HttpFoundation\JsonResponse;
//use Symfony\Component\Validator\Constraints\DateTime;
use AppBundle\Form\PrestationRechercheType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
/**
 * @Route("/mission")
 * @Security("has_role('ROLE_BUREAU')")
 */
class MissionController extends Controller
{
    /**
     * @Route("/mission",name="mission")
     */
    public function indexAction()
    {   
        $manager = $this->getDoctrine()->getManager();
        $form = $this->createForm(MissionFilterType::class);
        if (!is_null($response = $this->saveFilter($form, 'mission', 'mission'))) {
            return $response;
        }
        $qb = $manager->getRepository('AppBundle:Mission')->getMissionAll();
        $paginator = $this->filter($form, $qb, 'mission');
        $forme=$form->createView();
        return $this->render('@App/Mission/index.html.twig', array(
            'form'      => $form->createView(),
            'paginator' => $paginator,
        ));
    }
    /**
     * @Route("/new",name="mission_new")
     */
    public function newAction(Request $request)
    {
        $manager = $this->getDoctrine()->getManager();
        $mission = new Mission();
        $form = $this->createForm(MissionType::class, $mission);
        if ($form->handleRequest($request)->isValid())
        {
            //$annee = $form['annee']->getData();
            $annee = $request->request->get('mission')['annee'];
            $anneeMission = $mission->getDepart()->format('Y');
            /*if ($mission->getRetour() < $mission->getDepart())
            {
                $this->get('session')->getFlashBag()->add('danger', ' La date de départ doit être inférieur à la date de retour.');
            }else*/
            if( $annee != $anneeMission)
            {
                $this->get('session')->getFlashBag()->add('danger', " L'année [date de départ] doit être la même année du champ [année].");
            }else
            {
                $manager->persist($mission);
                $manager->flush();
                $this->get('session')->getFlashBag()->add('success', 'Enregistrement effectuer avec sucées.');
                $cryptage = $this->container->get('my.cryptage');
                return $this->redirect($this->generateUrl('mission_show', array('id' => $cryptage->my_encrypt($mission->getId()))));
            }
        }
        return $this->render('@App/Mission/new.html.twig', array(
            'mission' => $mission,
            'form'    => $form->createView(),
        ));
    }
    /**
     * @Route("/{id}/edit",name="mission_edit")
     * id : mission
     */
    public function editAction($id, Request $request)
    {   $cryptage = $this->container->get('my.cryptage');
        $id = $cryptage->my_decrypt($id);
        $mission = $this->getDoctrine()->getRepository('AppBundle:Mission')->find($id);
        $editForm = $this->createForm(MissionType::class, $mission, array(
            'action' => $this->generateUrl('mission_edit', array('id' => $cryptage->my_encrypt($mission->getId()))),
            'method' => 'PUT',
        ));
        $depart = $request->request->get('mission')['depart'];
        $retour = $request->request->get('mission')['retour'];
        //dump($depart);
        //throw new \Exception('Message');
        if ($editForm->handleRequest($request)->isValid()) {

            $dd = $this->getDoctrine()->getRepository('AppBundle:Intervention')->valideDate($id,$depart,$retour);
            $d1 = $dd["d1"];
            $d2 = $dd["d2"];
            dump($dd);

            if (($d1 !=null) or ($d2 != null)){
                if ($d1 != null){
                    $this->get('session')->getFlashBag()->add('danger', 'Date de départ doit être inférieur ou égale au : ' . $d1);
                }
                if ($d2 != null){
                    $this->get('session')->getFlashBag()->add('danger', 'Date de retour doit être supérieur ou égale au : ' . $d2);
                }
            }else{
                $this->getDoctrine()->getManager()->flush();
                $this->get('session')->getFlashBag()->add('success', 'Enregistrement effectuer avec sucées.');
                return $this->redirect($this->generateUrl('mission_edit', array('id' => $cryptage->my_encrypt($id))));
            }
        }
        return $this->render('@App/Mission/edit.html.twig', array(
            'mission'          => $mission,
            'edit_form'     => $editForm->createView(),
        ));
    }
    /**
     * @Route("/{id}/show",name="mission_show")
     * id : mission
     */
    public function showAction($id)
    {   $cryptage = $this->container->get('my.cryptage');
        $id = $cryptage->my_decrypt($id);
        $mission = $this->getDoctrine()->getRepository('AppBundle:Mission')->find($id);
        $destination = $this->getDoctrine()->getRepository('AppBundle:Intervention')->getDestination($id);
        $deleteForm = $this->createDeleteForm($id, 'mission_delete');
        return $this->render('@App/Mission/show.html.twig', array(
            'mission'       => $mission,
            'destination'   => $destination,
            'delete_form'   => $deleteForm->createView()));
    }
    /**
     * @Route("/{id}/delete",name="mission_delete")
     *
     */
    public function deleteAction(Mission $mission, Request $request)
       {
        $form = $this->createDeleteForm($mission->getId(), 'mission_delete');
        if ($form->handleRequest($request)->isValid()) {
            $manager = $this->getDoctrine()->getManager();
            $manager->remove($mission);
            try {
            $manager->flush();
            } catch(\Doctrine\DBAL\DBALException $e) {
                $this->get('session')->getFlashBag()->add('danger', 'Impossible de supprimer cette mission.');
                $cryptage = $this->container->get('my.cryptage');
                $id = $mission->getId();
                $id = $cryptage->my_encrypt($id);
                return $this->redirect($this->generateUrl('mission_show', array('id' => $id)));
            }
        }
        return $this->redirect($this->generateUrl('mission'));
    }
    /**
     * @Route("/{annee}/mission/next", name="mission_next",options = { "expose" = true })
     * 
     */
    public function missionNextAction($annee): Response
    {
        $manager = $this->getDoctrine()->getManager();
        $code = $manager->getRepository("AppBundle:Mission")->getNextMission($annee);
        return $this->json(["code" =>$code],200);
    }
    /**
     * @Route("/{id}/detail",name="mission_detail")
     * id : mission
     */
    public function missionDetailAction($id)
    {
        $cryptage = $this->container->get('my.cryptage');
        $id = $cryptage->my_decrypt($id);
        $mission         = $this->getDoctrine()->getRepository('AppBundle:Mission')->find($id);
        $destination     = $this->getDoctrine()->getRepository('AppBundle:Intervention')->getDestination($id);
        //$interventions = $this->getDoctrine()->getRepository('AppBundle:Intervention')->findBy(["mission" => $id]);
        $interventions =$this->getDoctrine()->getRepository('AppBundle:Intervention')->getInterventions($id);
        $realisateurs  =$this->getDoctrine()->getRepository('AppBundle:InterventionUser')->getRealisateurs($id);
        //dump($interventions);
        return $this->render('@App/Mission/mission.detail.html.twig', array(
            'mission'       => $mission,
            'destination'   => $destination,
            'interventions' => $interventions,
            'realisateurs'  => $realisateurs,
        ));
    }

    /**
     * @Route("/{id}/interventionNew",name="mission_intervention_new")
     * id : mission
     */
    public function missionInterventionNewAction($id,Request $request)
    {
        $manager = $this->getDoctrine()->getManager();
        $cryptage = $this->container->get('my.cryptage');
        $id = $cryptage->my_decrypt($id);
        $mission = $this->getDoctrine()->getRepository('AppBundle:Mission')->find($id);
        $intervention = new Intervention();
        $intervention->setMission($mission);
        $form_recherche_site = $this->createForm(SiteRechercheType::class);
        $form_recherche_prestation = $this->createForm(PrestationRechercheType::class);
        $form_intervention = $this->createForm(InterventionType::class, $intervention);
        
        $siteid = $request->request->get('intervention')['siteid'];
        $prestationid = $request->request->get('intervention')['prestationid'];

        if($siteid != null)
        {   
            $site = $this->getDoctrine()->getRepository('AppBundle:Site')->find($siteid);
            $intervention->setSite($site);
        }
        if($prestationid != null)
        {   
            $prestation = $this->getDoctrine()->getRepository('AppBundle:Prestation')->find($prestationid);
            $intervention->setPrestation($prestation);
        }
        if ($form_intervention->handleRequest($request)->isValid()) {
            dump($mission->getDepart());
            $dd =  $mission->getDepart()->format('d/m/Y');
            dump($dd);
            if (($intervention->getDateIntervention()<$mission->getDepart()) or ($intervention->getDateIntervention() > $mission->getRetour()) ){
                $this->get('session')->getFlashBag()->add('danger', "Date d'intervention doit être supérieur  ou égale à la date de départ: ". $mission->getDepart()->format('d/m/Y') ." et inférieur ou égale à la de retour: ". $mission->getRetour()->format("d/m/Y").".");
            }else{
                $manager->persist($intervention);
                $manager->flush();
            
                $this->get('session')->getFlashBag()->add('success', 'Enregistrement effectuer avec sucées.');
                return $this->redirect($this->generateUrl('mission_intervention_show', array('id' => $cryptage->my_encrypt($intervention->getId()))));
            }
        }
        $deleteForm = $this->createDeleteForm($id, 'mission_intervention_delete');
        return $this->render('@App/Mission/mission.intervention.new.html.twig', array(
            'id'                            => $id,
            'intervention'                  => $intervention,
            'form_intervention'             => $form_intervention->createView(),
            'form_recherche_site'           => $form_recherche_site->createView(),
            'form_recherche_prestation'     => $form_recherche_prestation->createView(),
            'form_delete'                   => $deleteForm->createView(),
            
        ));

    }
    /**
     * @Route("/{id}/interventionShow",name="mission_intervention_show")
     * id : intervention
     */
    public function missionInterventionShowAction($id,Request $request)
    {
        //$manager = $this->getDoctrine()->getManager();    
        $cryptage = $this->container->get('my.cryptage');
        $id = $cryptage->my_decrypt($id);
        $intervention = $this->getDoctrine()->getRepository('AppBundle:Intervention')->getIntervention($id);
        $realisateurs = $this->getDoctrine()->getRepository('AppBundle:InterventionUser')->getRealisateursIntervention($id);
        //dump($intervention);
        //dump($intervention->getId());
        $interventionUser = new InterventionUser();

        //$nonRealisateurs = $this->getDoctrine()->getRepository('AppBundle:InterventionUser')->getNotRealisateursIntervention($id);
        //dump($real);
        //throw new \Exception('Message');
        $form_realisateur = $this->createForm(InterventionUserType::class,$interventionUser,array('id'=>$intervention));
        //$form_realisateur = $this->createForm(new InterventionUserType($intervention),$interventionUser);
        //$form = $this->createForm(new DescriptionArticleType($article->getId()), $descriptionArticle);
        $deleteForm = $this->createDeleteForm($id, 'mission_intervention_delete');
        return $this->render('@App/Mission/mission.intervention.show.html.twig', array(
            'id'                            => $id,
            'intervention'                  => $intervention,
            'realisateurs'                  => $realisateurs,
            //'nonRealisateurs'               => $nonRealisateurs,
            'delete_form'                   => $deleteForm->createView(),
            'form_realisateur'              => $form_realisateur->createView(),
            
        ));

    }
    /**
     * @Route("/{id}/interventionEdit",name="mission_intervention_edit")
     * id : intervention
     */
    public function missionInterventionEditAction($id,Request $request)
    {
        $manager = $this->getDoctrine()->getManager();
        $cryptage = $this->container->get('my.cryptage');
        $id = $cryptage->my_decrypt($id);
        $intervention = $this->getDoctrine()->getRepository('AppBundle:Intervention')->find($id);
        //dump($intervention);

        $cryptage = $this->container->get('my.cryptage');
        //$id = $cryptage->my_decrypt($id);
        //$mission = $this->getDoctrine()->getRepository('AppBundle:Mission')->find($id);
        //$intervention = new Intervention();
        //$intervention->setMission($mission);
        $form_recherche_site = $this->createForm(SiteRechercheType::class);
        $form_recherche_prestation = $this->createForm(PrestationRechercheType::class);
        $form_intervention = $this->createForm(InterventionType::class, $intervention);
        $form_intervention->get('sitecode')->setData($intervention->getSite()->getCode());
        $form_intervention->get('sitenom')->setData($intervention->getSite()->getNom());
        $form_intervention->get('sousprojet')->setData($intervention->getPrestation()->getSousProjet()->getNom());
        $form_intervention->get('prestationnom')->setData($intervention->getPrestation()->getNom());
        
        $siteid = $request->request->get('intervention')['siteid'];
        $prestationid = $request->request->get('intervention')['prestationid'];

        if($siteid != null)
        {   
            $site = $this->getDoctrine()->getRepository('AppBundle:Site')->find($siteid);
            $intervention->setSite($site);
        }
        if($prestationid != null)
        {   
            $prestation = $this->getDoctrine()->getRepository('AppBundle:Prestation')->find($prestationid);
            $intervention->setPrestation($prestation);
        }
        if ($form_intervention->handleRequest($request)->isValid()) {
            if (($intervention->getDateIntervention()<$intervention->getMission()->getDepart()) or ($intervention->getDateIntervention() > $intervention->getMission()->getRetour()) ){
                $this->get('session')->getFlashBag()->add('danger', "Date d'intervention doit être supérieur  ou égale à la date de départ: ".$intervention->getMission()->getDepart()->format("d/m/Y")." et inférieur ou égale à la de retour: ".$intervention->getMission()->getRetour()->format("d/m/Y").".");
            }else{
                $manager->persist($intervention);
                $manager->flush();
            
                $this->get('session')->getFlashBag()->add('success', 'Enregistrement effectuer avec sucées.');
                //return $this->redirect($this->generateUrl('mission_intervention_show', array('id' => $cryptage->my_encrypt($intervention->getId()))));
            }
        }
        //$deleteForm = $this->createDeleteForm($id, 'mission_intervention_delete');
        return $this->render('@App/Mission/mission.intervention.edit.html.twig', array(
            //'id'                            => $id,
            'intervention'                  => $intervention,
            'form_intervention'             => $form_intervention->createView(),
            'form_recherche_site'           => $form_recherche_site->createView(),
            'form_recherche_prestation'     => $form_recherche_prestation->createView(),
            //'form_delete'                   => $deleteForm->createView(),
            
        ));

    }
    /**
     * @Route("/{id}/interventionDelete",name="mission_intervention_delete",options = { "expose" = true })
     * id : intervention
     */
    public function missionInterventiondeleteAction(Intervention $intervention, Request $request)
    {
        $manager = $this->getDoctrine()->getManager();
        $cryptage = $this->container->get('my.cryptage');
        $mission = $intervention->getMission();
        $manager->remove($intervention);
        try {
            $manager->flush();
        } catch(\Doctrine\DBAL\DBALException $e) {
            $this->get('session')->getFlashBag()->add('danger', 'Impossible de supprimer cet element.');
            $id = $intervention->getId();
            $id = $cryptage->my_encrypt($id);
            return $this->redirect($this->generateUrl('mission_intervention_show', array('id' => $id)));
        }
        $this->get('session')->getFlashBag()->add('success', 'Suppression avec succès.');
        return $this->redirect($this->generateUrl('mission_detail',array('id' => $cryptage->my_encrypt($mission->getId()))));

           /** */
        /*$form = $this->createDeleteForm($mission->getId(), 'mission_delete');
        if ($form->handleRequest($request)->isValid()) {
            $manager = $this->getDoctrine()->getManager();
            $manager->remove($mission);
            try {
            $manager->flush();
            } catch(\Doctrine\DBAL\DBALException $e) {
                $this->get('session')->getFlashBag()->add('danger', 'Impossible de supprimer cette mission.');
                $cryptage = $this->container->get('my.cryptage');
                $id = $mission->getId();
                $id = $cryptage->my_encrypt($id);
                return $this->redirect($this->generateUrl('mission_show', array('id' => $id)));
            }
        }
        return $this->redirect($this->generateUrl('mission'));*/
    }
    /**
     * @Route("/{id}/interventionrealisateuradd",name="mission_intervention_realisateur_add",options = { "expose" = true })
     * id : intervention
     */
    public function missionInterventionRealisateurAddAction($id,request $request){
           
        $manager = $this->getDoctrine()->getManager();
        $cryptage = $this->container->get('my.cryptage');
        $id = $cryptage->my_decrypt($id);
        $intervention = $manager->getRepository("AppBundle:Intervention")->find($id);
        //dump($intervention);
        //dump($request->request->all());
        //getNotRealisateursIntervention
        //$users = $manager->getRepository("AppBundle:InterventionUser")->getNotRealisateursIntervention($id);
        //dump($users);
        //throw new \Exception('Message');

        $quest = $request->request->all()["intervention_user"]["User"];
        //dump($quest);  
        
        foreach($quest as $realisateur){
            //dump($realisateur);
            $user = $manager->getRepository("AppBundle:User")->find($realisateur);
            $interventionUser = new InterventionUser();
            $interventionUser->setUser($user);
            $interventionUser->setIntervention($intervention);
            
            $manager->persist($interventionUser);
            $manager->flush();
        }
        

       
        //$realisateurs = $manager->getRepository("AppBundle:Intervention")->getRealisateursIntervention($id);

        return $this->redirect($this->generateUrl('mission_intervention_show', array('id' => $cryptage->my_encrypt($id))));

    }
    /**
     * @Route("/{user}/{intervention}/deleteInterventionUser",name="intervention_realisateur_delete",options = {"expose" = true})
     */
    public function deleteInterventionUserAction(User $user,Intervention $intervention){
        $manager = $this->getDoctrine()->getManager();
        $cryptage = $this->container->get('my.cryptage');
        $interventionUser = $manager->getRepository("AppBundle:InterventionUser")->find(['user'=>$user,'intervention'=>$intervention]);
        $mission = $intervention->getMission();
        $manager->remove($interventionUser);
        try {
            $manager->flush();
        } catch(\Doctrine\DBAL\DBALException $e) {
            $this->get('session')->getFlashBag()->add('danger', 'Impossible de supprimer cet element.');
            return $this->redirect($this->generateUrl('mission_intervention_show', array('id' => $cryptage->my_encrypt($intervention->getid()))));
        }
        $this->get('session')->getFlashBag()->add('success', 'Suppression avec succès.');
        return $this->redirect($this->generateUrl('mission_intervention_show', array('id' => $cryptage->my_encrypt($intervention->getid()))));
    }

    /**
     * @Route("/{client}/{pagenum}/searchSite/{site}",name="search_site",options = { "expose" = true })
     */
    public function searchSiteAction($client,$pagenum,$site=null)
    {
        $manager = $this->getDoctrine()->getManager();
        $maxRows = 10 ;// parametre
        $startRow = $pagenum * $maxRows;
        $totalRows = $manager->getRepository("AppBundle:Site")->getTotalRows($client,$site);
        $totalpages = ceil($totalRows/$maxRows)-1;
        $sites = $manager->getRepository("AppBundle:Site")->getSites($client,$site,$startRow,$maxRows);
        $sites = $sites->getQuery()->getResult();
        return $this->json(["sites"     => $sites,
                            "pagenum"   => $pagenum,
                            "totalpages"=> $totalpages,
                            ],
                            200);
    }

    /**
     * @Route("/{sousprojet}/{pagenum}/searchPrestation/{prestation}",name="search_prestation",options = { "expose" = true })
     */
    public function searchPrestationAction($sousprojet,$pagenum,$prestation=null)
    {
        $manager = $this->getDoctrine()->getManager();
        $maxRows = 10 ;// parametre
        $startRow = $pagenum * $maxRows;
        $totalRows = $manager->getRepository("AppBundle:Prestation")->getTotalRows($sousprojet,$prestation);
        $totalpages = ceil($totalRows/$maxRows)-1;
        $prestations = $manager->getRepository("AppBundle:Prestation")->getPrestations($sousprojet,$prestation,$startRow,$maxRows);
        $prestations = $prestations->getQuery()->getResult();
        return $this->json(["prestations"     => $prestations,
                            "pagenum"   => $pagenum,
                            "totalpages"=> $totalpages,
                            ],
                            200);
    }
    

    //*********************************************************************************//
    /**
    * @route("/{field}/{type}/sort",name="mission_sort",requirements={ "type"="ASC|DESC" })
    */
    public function sortAction($field, $type)
    {
        $this->setOrder('mission', $field, $type);
        return $this->redirect($this->generateUrl('mission'));
    }
    /**
     * Create Delete form
     *
     * @param integer                       $id
     * @param string                        $route
     * @return \Symfony\Component\Form\Form
     */
    protected function createDeleteForm($id, $route)
    {
        return $this->createFormBuilder(null, array('attr' => array('id' => 'delete')))
            ->setAction($this->generateUrl($route, array('id' => $id)))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
    /**
     * @param string $name  session name
     * @param string $field field name
     * @param string $type  sort type ("ASC"/"DESC")
     */
    protected function setOrder($name, $field, $type = 'ASC')
    {
        $request = $this->container->get('request_stack')->getCurrentRequest();
        $request->getSession()->set('sort.' . $name, array('field' => $field, 'type' => $type));
    }
    protected function saveFilter(FormInterface $form, $name, $route = null, array $params = null)
    {
        //$request = $this->getRequest();
        $request = $this->container->get('request_stack')->getCurrentRequest();
        $url = $this->generateUrl($route ?: $name, is_null($params) ? array() : $params);
        if ($request->query->has('submit-filter') && $form->handleRequest($request)->isValid()) {
            $request->getSession()->set('filter.' . $name, $request->query->get($form->getName()));
            return $this->redirect($url);
        } elseif ($request->query->has('reset-filter')) {
            $request->getSession()->set('filter.' . $name, null);
            return $this->redirect($url);
        }
    }
    protected function filter(FormInterface $form, QueryBuilder $qb, $name)
    {   
        if (!is_null($values = $this->getFilter($name))) {
            if ($form->submit($values)->isValid()) {
                $this->get('lexik_form_filter.query_builder_updater')->addFilterConditions($form, $qb);
            }
        }
        // possible sorting
        // nombre de ligne
        $session = $this->get('session');
        $nbr_pages = $session->get("nbr_pages");
        $this->addQueryBuilderSort($qb, $name);
        $request = $this->container->get('request_stack')->getCurrentRequest();
        return $this->get('knp_paginator')->paginate($qb, $request->query->get('page', 1), $nbr_pages);
    }
    protected function getFilter($name)
    {   $request = $this->container->get('request_stack')->getCurrentRequest();
        return $request->getSession()->get('filter.' . $name);
    }
    protected function addQueryBuilderSort(QueryBuilder $qb, $name)
    {
        $alias = current($qb->getDQLPart('from'))->getAlias();
        if (is_array($order = $this->getOrder($name))) {
            $qb->orderBy($alias . '.' . $order['field'], $order['type']);
        }
    }
    protected function getOrder($name)
    {
        $request = $this->container->get('request_stack')->getCurrentRequest();
        $session = $request->getSession();
        return $session->has('sort.' . $name) ? $session->get('sort.' . $name) : null;
    }
}