<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * InterventionUser
 *
 * @ORM\Table(name="intervention_user")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\InterventionUserRepository")
 *
 */
class InterventionUser
{

    /**
     * @ORM\Id
     * @ORM\ManyToOne(targetEntity="AppBundle\Entity\Intervention")
     * @Assert\NotBlank(message="il faut affecté une intervention")
     */
    private $intervention;

    /**
     * @ORM\Id
     * @ORM\ManyToOne(targetEntity="AppBundle\Entity\User")
     * @Assert\NotBlank(message="il faut affecté un employe")
     */
    private $user;

    /**
     * Set intervention
     *
     * @param \AppBundle\Entity\Intervention $intervention
     *
     * @return InterventionUser
     */
    public function setIntervention(\AppBundle\Entity\Intervention $intervention = null)
    {
        $this->intervention = $intervention;

        return $this;
    }

    /**
     * Get intervention
     *
     * @return \AppBundle\Entity\Intervention
     */
    public function getIntervention()
    {
        return $this->intervention;
    }

    /**
     * Set user
     *
     * @param \AppBundle\Entity\User $user
     *
     * @return InterventionUser
     */
    public function setUser(\AppBundle\Entity\User $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \AppBundle\Entity\User
     */
    public function getUser()
    {
        return $this->user;
    }
}
