<?php
namespace AppBundle\Entity;
use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
/**
 *
 * @ORM\Table(name="fonction_user")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\FonctionUserRepository")
 * @UniqueEntity(fields={"datefonction","user"},errorPath="datefonction",message="Une fonction attribuer déja à cette date.")
 */
class FonctionUser
{
    /**
     * @ORM\Id
     * @ORM\ManyToOne(targetEntity="AppBundle\Entity\User")
     */
    private $user;
    /**
     * @ORM\Id
     * @ORM\Column(type="string")
     */
    private $datefonction;
    /**
     * @ORM\ManyToOne(targetEntity="AppBundle\Entity\Fonction",cascade={"remove"})
     */
    private $fonction;
    /**
     * Set datefonction
     *
     * @param date $datefonction
     *
     * @return FonctionUser
     */
    public function setDatefonction($datefonction)
    {
        $this->datefonction = $datefonction->format("Y-m-d");
        return $this;
    }
    /**
     * Get datefonction
     *
     * @return date
     */
    public function getDatefonction()
    {
        return new DateTime($this->datefonction);
    }
    /**
     * Set user
     *
     * @param \AppBundle\Entity\User $user
     *
     * @return FonctionUser
     */
    public function setUser(\AppBundle\Entity\User $user)
    {
        $this->user = $user;
        return $this;
    }
    /**
     * Get user
     *
     * @return \AppBundle\Entity\User
     */
    public function getUser()
    {
        return $this->user;
    }
    /**
     * Set fonction
     *
     * @param \AppBundle\Entity\Fonction $fonction
     *
     * @return FonctionUser
     */
    public function setFonction(\AppBundle\Entity\Fonction $fonction = null)
    {
        $this->fonction = $fonction;
        return $this;
    }
    /**
     * Get fonction
     *
     * @return \AppBundle\Entity\Fonction
     */
    public function getFonction()
    {
        return $this->fonction;
    }
}
